#include "ZoneMapView.h"
#include "../../audio/multisampler/MultisamplerInstrument.h"
#include "../../audio/SfzZoneColours.h"
#include "../../PluginProcessor.h"
#include "../DysektLookAndFeel.h"
#include <algorithm>
#include <cmath>

ZoneMapView::ZoneMapView (DysektProcessor& processorToUse)
    : processor (processorToUse)
{
    // Needs focus now so Delete/Backspace (see keyPressed) can reach this
    // component — previously false because nothing here consumed key
    // events at all.
    setWantsKeyboardFocus (true);
    startTimerHz (30);   // matches KeysPanel's poll rate for the same atomics
}

ZoneMapView::~ZoneMapView()
{
    stopTimer();
}

bool ZoneMapView::isNoteActive (int note) const noexcept
{
    if (note < 0 || note > 127) return false;
    const uint64_t word = (note < 64) ? activeNotesSnap[0] : activeNotesSnap[1];
    const int      bit  = (note < 64) ? note : (note - 64);
    return ((word >> bit) & 1) != 0;
}

void ZoneMapView::timerCallback()
{
    // Same bitmask MultisamplerEditor's engine-sync path plays through
    // (sfzPlayer2) — see this class's header comment. Torn reads are fine,
    // same as KeysPanel's identical use of these atomics: display-only.
    const uint64_t lo = processor.sfz2ActiveNotes[0].load (std::memory_order_relaxed);
    const uint64_t hi = processor.sfz2ActiveNotes[1].load (std::memory_order_relaxed);
    if (lo != activeNotesSnap[0] || hi != activeNotesSnap[1])
    {
        activeNotesSnap[0] = lo;
        activeNotesSnap[1] = hi;
        repaint();
    }
}

// ── Public API ───────────────────────────────────────────────────────────

void ZoneMapView::setInstrument (MultisamplerInstrument* instrumentToShow)
{
    instrument = instrumentToShow;
    selectedIds.clear();
    dragMode = DragMode::none;
    rebuildLayout();
    repaint();
}

void ZoneMapView::refresh()
{
    rebuildLayout();
    repaint();
}

void ZoneMapView::setSelectedZoneIds (std::vector<juce::Uuid> ids)
{
    selectedIds = std::move (ids);
    repaint();
}

// ── Grid geometry ────────────────────────────────────────────────────────

juce::Rectangle<int> ZoneMapView::gridArea() const
{
    return getLocalBounds().withTrimmedLeft (kVelocityRulerPx)
                            .withTrimmedBottom (kKeyboardStripPx);
}

float ZoneMapView::xForKey (int key) const
{
    const auto g = gridArea();
    const float t = juce::jlimit (0.0f, 1.0f, (float) key / 127.0f);
    return (float) g.getX() + t * (float) g.getWidth();
}

float ZoneMapView::yForVelocity (int velocity) const
{
    const auto g = gridArea();
    // velocity 1..127, 127 drawn at the top (y == g.getY())
    const float t = juce::jlimit (0.0f, 1.0f, ((float) velocity - 1.0f) / 126.0f);
    return (float) g.getY() + (1.0f - t) * (float) g.getHeight();
}

int ZoneMapView::keyForX (float x) const
{
    const auto g = gridArea();
    if (g.getWidth() <= 0) return 0;
    const float t = juce::jlimit (0.0f, 1.0f, (x - (float) g.getX()) / (float) g.getWidth());
    return juce::jlimit (0, 127, (int) std::round (t * 127.0f));
}

int ZoneMapView::velocityForY (float y) const
{
    const auto g = gridArea();
    if (g.getHeight() <= 0) return 127;
    const float t = juce::jlimit (0.0f, 1.0f, (y - (float) g.getY()) / (float) g.getHeight());
    return juce::jlimit (1, 127, (int) std::round ((1.0f - t) * 126.0f + 1.0f));
}

void ZoneMapView::rebuildLayout()
{
    cachedRects.clear();
    if (instrument == nullptr) return;

    // Half a cell's width/height in each axis, derived from xForKey/
    // yForVelocity themselves rather than a separate denominator, so a
    // single-key or single-velocity zone still renders with visible
    // thickness and the top/bottom-most values (127 and 1) don't collapse
    // to a zero-size sliver at the grid edge.
    const float halfKeyW = std::abs (xForKey (1) - xForKey (0)) * 0.5f;
    const float halfVelH = std::abs (yForVelocity (1) - yForVelocity (2)) * 0.5f;

    const auto g = gridArea().toFloat();

    cachedRects.reserve (instrument->zones.size());
    int colIdx = 0;
    for (const auto& z : instrument->zones)
    {
        ZoneRect r;
        r.id = z.id;
        r.missingSample = z.hasMissingSample();

        // A user-picked colour (see showZoneContextMenu) always wins over
        // the palette-index default, matching MultisamplerEditor::
        // toKeyzones()'s identical preference — otherwise a manually
        // recoloured zone would look "reset" the moment another zone above
        // it shifts every subsequent palette index.
        if (z.hasCustomColour)
            r.colour = juce::Colour (z.customColourArgb);
        else
            r.colour = z.enabled ? SfzZoneColours::zoneColour (colIdx) : getTheme().foreground.withAlpha (0.25f);
        if (z.enabled) ++colIdx;

        const float x0 = xForKey (z.lowKey)  - halfKeyW;
        const float x1 = xForKey (z.highKey) + halfKeyW;
        const float y0 = yForVelocity (z.highVelocity) - halfVelH;   // top (smaller y — higher velocity)
        const float y1 = yForVelocity (z.lowVelocity)  + halfVelH;   // bottom

        juce::Rectangle<float> bounds (x0, y0, juce::jmax (2.0f, x1 - x0), juce::jmax (2.0f, y1 - y0));
        r.bounds = bounds.getIntersection (g);
        if (r.bounds.isEmpty()) r.bounds = bounds;   // fully off-grid zone (shouldn't happen) — keep visible rather than vanish

        cachedRects.push_back (r);
    }

    for (const auto& pair : instrument->findOverlappingPairs())
    {
        if (pair.first  < cachedRects.size()) cachedRects[pair.first].overlapping  = true;
        if (pair.second < cachedRects.size()) cachedRects[pair.second].overlapping = true;
    }
}

// ── Hit testing ──────────────────────────────────────────────────────────

const ZoneMapView::ZoneRect* ZoneMapView::topmostZoneAt (juce::Point<float> p) const
{
    // Later zones are drawn on top (see MultisamplerInstrument::zonesMatching
    // doc comment), so search back-to-front.
    for (auto it = cachedRects.rbegin(); it != cachedRects.rend(); ++it)
        if (it->bounds.contains (p))
            return &(*it);
    return nullptr;
}

ZoneMapView::DragMode ZoneMapView::hitTestEdges (const ZoneRect& r, juce::Point<float> p) const
{
    const bool nearLeft   = std::abs (p.x - r.bounds.getX())      <= (float) kEdgeGrabPx;
    const bool nearRight  = std::abs (p.x - r.bounds.getRight())  <= (float) kEdgeGrabPx;
    const bool nearTop    = std::abs (p.y - r.bounds.getY())      <= (float) kEdgeGrabPx;
    const bool nearBottom = std::abs (p.y - r.bounds.getBottom()) <= (float) kEdgeGrabPx;

    // Corners aren't independently draggable in this first pass — key range
    // and velocity range resize one axis at a time, which is enough for the
    // plan's Phase 2 acceptance criteria ("resize key or velocity boundaries").
    if (nearLeft)   return DragMode::resizeLeft;
    if (nearRight)  return DragMode::resizeRight;
    if (nearTop)    return DragMode::resizeTop;
    if (nearBottom) return DragMode::resizeBottom;
    return DragMode::move;
}

// ── Mouse handling ───────────────────────────────────────────────────────

void ZoneMapView::mouseDown (const juce::MouseEvent& e)
{
    if (instrument == nullptr) return;

    grabKeyboardFocus();   // so a subsequent Delete/Backspace (see keyPressed) reaches this component

    const auto p = e.position;
    const auto* hit = topmostZoneAt (p);

    if (hit == nullptr)
    {
        if (! e.mods.isShiftDown() && ! selectedIds.empty())
        {
            selectedIds.clear();
            if (onSelectionChanged) onSelectionChanged();
            repaint();
        }
        dragMode = DragMode::none;
        return;
    }

    if (e.mods.isRightButtonDown())
    {
        // Right-click always at least targets the clicked zone, same as
        // ZONES' onRowRightClicked — select it first (unless it's already
        // part of a multi-selection the user is about to bulk-delete) so
        // "Delete Zone" has an unambiguous target.
        if (std::find (selectedIds.begin(), selectedIds.end(), hit->id) == selectedIds.end())
        {
            selectedIds = { hit->id };
            if (onSelectionChanged) onSelectionChanged();
            repaint();
        }
        showZoneContextMenu (hit->id, e.getScreenPosition());
        dragMode = DragMode::none;
        return;
    }

    if (e.mods.isShiftDown())
    {
        const auto already = std::find (selectedIds.begin(), selectedIds.end(), hit->id);
        if (already != selectedIds.end()) selectedIds.erase (already);
        else                              selectedIds.push_back (hit->id);
    }
    else if (std::find (selectedIds.begin(), selectedIds.end(), hit->id) == selectedIds.end())
    {
        selectedIds = { hit->id };
    }
    if (onSelectionChanged) onSelectionChanged();

    auto* zone = instrument->findZone (hit->id);
    if (zone == nullptr) { repaint(); return; }

    dragMode          = hitTestEdges (*hit, p);
    dragZoneId         = hit->id;
    dragStartMouse      = e.getPosition();
    dragStartLowKey    = zone->lowKey;
    dragStartHighKey   = zone->highKey;
    dragStartLowVel    = zone->lowVelocity;
    dragStartHighVel   = zone->highVelocity;
    dragChangedAnything = false;

    repaint();
}

void ZoneMapView::mouseDrag (const juce::MouseEvent& e)
{
    if (instrument == nullptr || dragMode == DragMode::none) return;
    auto* zone = instrument->findZone (dragZoneId);
    if (zone == nullptr) return;

    const int dxKeys = keyForX ((float) e.getPosition().x) - keyForX ((float) dragStartMouse.x);
    const int dyVel  = velocityForY ((float) e.getPosition().y) - velocityForY ((float) dragStartMouse.y);

    switch (dragMode)
    {
        case DragMode::move:
        {
            const int span = dragStartHighKey - dragStartLowKey;
            int newLow  = juce::jlimit (0, 127 - span, dragStartLowKey + dxKeys);
            zone->lowKey  = newLow;
            zone->highKey = newLow + span;

            const int vspan = dragStartHighVel - dragStartLowVel;
            int newLowVel = juce::jlimit (1, 127 - vspan, dragStartLowVel + dyVel);
            zone->lowVelocity  = newLowVel;
            zone->highVelocity = newLowVel + vspan;
            break;
        }
        case DragMode::resizeLeft:
            zone->lowKey = juce::jlimit (0, zone->highKey, dragStartLowKey + dxKeys);
            break;
        case DragMode::resizeRight:
            zone->highKey = juce::jlimit (zone->lowKey, 127, dragStartHighKey + dxKeys);
            break;
        case DragMode::resizeTop:
            zone->highVelocity = juce::jlimit (zone->lowVelocity, 127, dragStartHighVel + dyVel);
            break;
        case DragMode::resizeBottom:
            zone->lowVelocity = juce::jlimit (1, zone->highVelocity, dragStartLowVel + dyVel);
            break;
        case DragMode::none:
        default:
            return;
    }

    dragChangedAnything = true;
    rebuildLayout();
    repaint();
    if (onZoneEditing) onZoneEditing();
}

void ZoneMapView::mouseUp (const juce::MouseEvent&)
{
    const bool shouldNotify = dragChangedAnything && dragMode != DragMode::none;
    dragMode = DragMode::none;
    dragChangedAnything = false;
    if (shouldNotify && onZoneEditCommitted) onZoneEditCommitted();
}

void ZoneMapView::mouseMove (const juce::MouseEvent& e)
{
    const auto* hit = topmostZoneAt (e.position);
    const auto newHover = hit != nullptr ? hit->id : juce::Uuid::null();
    if (newHover != hoverZoneId)
    {
        hoverZoneId = newHover;
        repaint();
    }

    if (hit != nullptr)
    {
        switch (hitTestEdges (*hit, e.position))
        {
            case DragMode::resizeLeft:
            case DragMode::resizeRight:  setMouseCursor (juce::MouseCursor::LeftRightResizeCursor); break;
            case DragMode::resizeTop:
            case DragMode::resizeBottom: setMouseCursor (juce::MouseCursor::UpDownResizeCursor);    break;
            default:                     setMouseCursor (juce::MouseCursor::DraggingHandCursor);    break;
        }
    }
    else
    {
        setMouseCursor (juce::MouseCursor::NormalCursor);
    }
}

void ZoneMapView::mouseExit (const juce::MouseEvent&)
{
    if (hoverZoneId != juce::Uuid::null())
    {
        hoverZoneId = juce::Uuid::null();
        repaint();
    }
    setMouseCursor (juce::MouseCursor::NormalCursor);
}

void ZoneMapView::resized()
{
    rebuildLayout();
}

// ── Deletion ─────────────────────────────────────────────────────────────

bool ZoneMapView::keyPressed (const juce::KeyPress& key)
{
    if (instrument == nullptr || selectedIds.empty())
        return false;

    if (key == juce::KeyPress::deleteKey || key == juce::KeyPress::backspaceKey)
    {
        // Delete-key path always targets the current selection as a whole
        // (there's no single "clicked" zone here), unlike the right-click
        // menu's single-target default — matches ZONES having no keyboard
        // shortcut for this at all today, so this is pure upside rather
        // than a behaviour change to match.
        deleteZones (selectedIds.front());
        return true;
    }
    return false;
}

void ZoneMapView::deleteZones (const juce::Uuid& rightClickedId)
{
    if (instrument == nullptr) return;

    // If the right-clicked/keyed zone is part of the current multi-
    // selection, delete the whole selection; otherwise it's a lone
    // right-click on a zone that isn't selected, so only that one goes.
    std::vector<juce::Uuid> toDelete;
    if (std::find (selectedIds.begin(), selectedIds.end(), rightClickedId) != selectedIds.end())
        toDelete = selectedIds;
    else
        toDelete = { rightClickedId };

    bool anyRemoved = false;
    for (const auto& id : toDelete)
        anyRemoved |= instrument->removeZone (id);

    if (! anyRemoved) return;

    selectedIds.clear();
    dragMode = DragMode::none;
    rebuildLayout();
    repaint();

    if (onSelectionChanged)  onSelectionChanged();
    if (onZoneDeleted)       onZoneDeleted();
}

// ── Context menu ─────────────────────────────────────────────────────────

void ZoneMapView::showZoneContextMenu (const juce::Uuid& zoneId, juce::Point<int> screenPos)
{
    if (instrument == nullptr) return;
    auto* zone = instrument->findZone (zoneId);
    if (zone == nullptr) return;

    // Same 16-colour named palette as ZONES' onRowRightClicked (see
    // PluginEditor.cpp) and the Slicer's "Slice Color" picker (SliceLane.cpp)
    // — kept identical so the colour-picker UX matches everywhere in the
    // app a zone/slice can be recoloured.
    static const struct { const char* name; juce::uint32 argb; } kPal[] = {
        { "Cyan",    0xFF00C8FF }, { "Green",   0xFF00FF87 },
        { "Yellow",  0xFFFFE800 }, { "Orange",  0xFFFF6B00 },
        { "Red",     0xFFFF2D55 }, { "Pink",    0xFFFF2D9A },
        { "Violet",  0xFFB44FFF }, { "Blue",    0xFF4A80FF },
        { "Sky",     0xFF00BFFF }, { "Mint",    0xFF00FFD0 },
        { "Lime",    0xFFA8FF3E }, { "Gold",    0xFFFFD700 },
        { "Coral",   0xFFFF7F50 }, { "Magenta", 0xFFFF00FF },
        { "White",   0xFFE8E8E8 }, { "Silver",  0xFF888888 },
    };

    const juce::Colour curCol = zone->hasCustomColour
                                     ? juce::Colour (zone->customColourArgb)
                                     : juce::Colours::transparentBlack;
    juce::PopupMenu colourSub;
    for (int ci = 0; ci < 16; ++ci)
    {
        juce::Colour c ((juce::uint32) kPal[ci].argb);
        colourSub.addColouredItem (20 + ci, kPal[ci].name, c,
                                   true, zone->hasCustomColour && c.toDisplayString (false) == curCol.toDisplayString (false));
    }

    auto* topLvl = getTopLevelComponent();
    float ms = DysektLookAndFeel::getMenuScale();
    juce::PopupMenu menu;
    const bool multi = std::find (selectedIds.begin(), selectedIds.end(), zoneId) != selectedIds.end()
                            && selectedIds.size() > 1;
    menu.addItem (1, multi ? "Delete " + juce::String ((int) selectedIds.size()) + " Zones" : "Delete Zone");
    menu.addSeparator();
    menu.addSubMenu ("Zone Color", colourSub);
    menu.showMenuAsync (
        juce::PopupMenu::Options()
            .withTargetScreenArea (juce::Rectangle<int> (screenPos.x, screenPos.y, 1, 1))
            .withParentComponent (topLvl)
            .withStandardItemHeight ((int) (24 * ms)),
        [this, zoneId] (int result)
        {
            if (instrument == nullptr) return;   // view may have been repointed while the menu was open

            if (result == 1)
            {
                deleteZones (zoneId);
            }
            else if (result >= 20 && result < 36)
            {
                static const juce::uint32 kPalARGB[] = {
                    0xFF00C8FF, 0xFF00FF87, 0xFFFFE800, 0xFFFF6B00,
                    0xFFFF2D55, 0xFFFF2D9A, 0xFFB44FFF, 0xFF4A80FF,
                    0xFF00BFFF, 0xFF00FFD0, 0xFFA8FF3E, 0xFFFFD700,
                    0xFFFF7F50, 0xFFFF00FF, 0xFFE8E8E8, 0xFF888888,
                };
                auto* z = instrument->findZone (zoneId);
                if (z == nullptr) return;
                z->hasCustomColour  = true;
                z->customColourArgb = kPalARGB[result - 20];
                rebuildLayout();
                repaint();
                if (onZoneEditCommitted) onZoneEditCommitted();   // persists via the normal debounced-resync/dirty path
            }
        });
}

// ── Painting ─────────────────────────────────────────────────────────────

void ZoneMapView::paint (juce::Graphics& g)
{
    const auto& theme = getTheme();
    const auto g_area = gridArea();

    g.fillAll (theme.waveformBg);

    // Octave gridlines (C notes every 12 semitones) + black-key shading.
    g.setColour (theme.gridLine.withAlpha (0.35f));
    for (int key = 0; key <= 127; key += 12)
    {
        const float x = xForKey (key);
        g.drawVerticalLine ((int) x, (float) g_area.getY(), (float) g_area.getBottom());
    }

    // Velocity gridlines every 32.
    for (int v = 1; v <= 127; v += 32)
    {
        const float y = yForVelocity (v);
        g.drawHorizontalLine ((int) y, (float) g_area.getX(), (float) g_area.getRight());
    }

    // Velocity ruler.
    g.setColour (theme.foreground.withAlpha (0.5f));
    g.setFont (juce::FontOptions (10.0f));
    for (int v = 127; v >= 1; v -= 32)
        g.drawText (juce::String (v), 0, (int) yForVelocity (v) - 7, kVelocityRulerPx - 3, 14,
                    juce::Justification::centredRight);

    // Piano-key strip along the bottom (just black/white shading, no labels
    // beyond octave C markers — this is a mapping aid, not a keyboard widget).
    // Notes currently sounding through sfzPlayer2 (real MIDI input, on-screen
    // keyboard clicks elsewhere, or MULTISAMPLER's own preview — anything
    // that lights up processor.sfz2ActiveNotes) light up in the theme accent
    // colour, same as KeysPanel's keyboard does for ZONES.
    static const bool blackKey[12] = { false, true, false, true, false, false, true, false, true, false, true, false };
    for (int key = 0; key < 128; ++key)
    {
        const float x0 = xForKey (key);
        const float x1 = xForKey (key + 1);
        const bool active = isNoteActive (key);
        g.setColour (active
                        ? theme.accent
                        : (blackKey[key % 12] ? theme.darkBar : theme.foreground.withAlpha (0.15f)));
        g.fillRect (juce::Rectangle<float> (x0, (float) g_area.getBottom(), x1 - x0, (float) kKeyboardStripPx));
    }
    g.setColour (theme.separator);
    g.drawHorizontalLine (g_area.getBottom(), (float) g_area.getX(), (float) g_area.getRight());

    // Zones.
    for (const auto& r : cachedRects)
    {
        const bool selected = std::find (selectedIds.begin(), selectedIds.end(), r.id) != selectedIds.end();
        const bool hovered   = r.id == hoverZoneId;

        const bool sounding = [&]
        {
            const auto* zone = instrument != nullptr ? instrument->findZone (r.id) : nullptr;
            if (zone == nullptr) return false;
            for (int n = 0; n < 128; ++n)
                if (isNoteActive (n) && zone->keyInRange (n)) return true;
            return false;
        }();

        auto fill = r.missingSample ? juce::Colours::red.withAlpha (0.25f)
                                     : r.colour.withAlpha (sounding ? 0.80f : (selected ? 0.55f : (hovered ? 0.38f : 0.24f)));
        g.setColour (fill);
        g.fillRect (r.bounds);

        if (r.overlapping)
        {
            // Diagonal hatch to flag overlapping key/velocity ranges (plan §6,
            // "visual indication of overlaps").
            g.saveState();
            g.reduceClipRegion (r.bounds.toNearestInt());
            g.setColour (theme.foreground.withAlpha (0.20f));
            for (float x = r.bounds.getX() - r.bounds.getHeight(); x < r.bounds.getRight(); x += 6.0f)
                g.drawLine (x, r.bounds.getBottom(), x + r.bounds.getHeight(), r.bounds.getY(), 1.0f);
            g.restoreState();
        }

        g.setColour (sounding ? juce::Colours::white : (selected ? theme.accent : theme.separator.withAlpha (0.8f)));
        g.drawRect (r.bounds, (sounding || selected) ? 2.0f : 1.0f);

        if (r.missingSample)
        {
            g.setColour (juce::Colours::red.withAlpha (0.85f));
            g.setFont (juce::FontOptions (10.0f, juce::Font::bold));
            g.drawText ("!", r.bounds.toNearestInt(), juce::Justification::topLeft);
        }
    }

    if (instrument == nullptr || instrument->zones.empty())
    {
        g.setColour (theme.foreground.withAlpha (0.4f));
        g.setFont (juce::FontOptions (13.0f));
        g.drawText ("Drop samples here or import an SFZ to start mapping",
                    g_area, juce::Justification::centred);
    }
}
