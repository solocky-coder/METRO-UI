#pragma once
#include "SequencerTrack.h"
#include "AbletonLink.h"
#include <juce_audio_basics/juce_audio_basics.h>
#include <atomic>
#include <memory>
#include <vector>

//==============================================================================
//  LiveTargetPlayer / SelectedLiveTarget  —  see
//  docs/selected-track-live-midi-workflow.md and
//  SequencerEngine::getSelectedLiveTarget().
//==============================================================================
enum class LiveTargetPlayer { none, slicer, sf2, sfz };

struct SelectedLiveTarget
{
    LiveTargetPlayer player      = LiveTargetPlayer::none;
    int              midiChannel = 0;   // 1-based; 0 = none
};

//==============================================================================
//  SequencerTrackInfo  —  lightweight metadata snapshot of a SequencerTrack.
//==============================================================================
struct SequencerTrackInfo
{
    TrackType     type        = TrackType::MainSlice;
    bool          enabled     = true;
    bool          solo        = false;
    float         volumeDb    = 0.0f;   // -60..+6, not yet applied to audio output
    float         pan         = 0.0f;   // -1..+1, not yet applied to audio output
    juce::String  name;
    juce::Colour  colour      = juce::Colour (0xFF3A6080);
    int           sliceIdx    = -1;
    int           midiChannel = 0;
    Sf2PresetInfo preset;
    int           numClips    = 0;
    // See SequencerTrack::isSfzInstrument — only meaningful when
    // type == TrackType::SfPlayer; distinguishes a real .sfz-file
    // instrument track from an SF2 preset track.
    bool          isSfzInstrument = false;
};

//==============================================================================
//  SequencerClipInfo  —  lightweight snapshot of a single ClipSlot.
//==============================================================================
struct SequencerClipInfo
{
    int64_t startTick  = 0;
    int64_t lengthTicks = MidiClip::kPPQ * 4 * 4;
    int64_t endTick() const noexcept { return startTick + lengthTicks; }
};

class SequencerEngine
{
public:
    SequencerEngine();
    ~SequencerEngine();

    //==========================================================================
    //  Transport
    //==========================================================================
    bool    isPlaying()         const noexcept;
    bool    isLooping()         const noexcept;
    bool    isRecording()       const noexcept;
    int64_t getPlayheadTick()   const noexcept;
    double  getPlayheadBeats()  const noexcept;
    float   getBpm()            const noexcept;
    bool    getSyncToHost()     const noexcept;

    /** Global length = end of last clip across all tracks (governs playhead wrap). */
    int64_t getLengthTicks()    const noexcept;
    int64_t getLoopStartTick() const noexcept;
    int64_t getLoopEndTick()   const noexcept;

    void play();
    void stop();
    void rewind();

    void setLooping   (bool v);
    void setRecording (bool v);
    void setSyncToHost(bool v);
    void setBpm       (float b);
    void setHostBpm   (float b);
    void seekToTick   (int64_t tick);
    /** Sets the inclusive-start/exclusive-end cycle range used while looping. */
    void setLoopRange (int64_t startTick, int64_t endTick);

    /** Backward-compat: sets clip 0 length on all tracks. */
    void setLengthTicks (int64_t ticks);

    //==========================================================================
    //  Track management  (message thread)
    //==========================================================================
    int                getNumTracks()       const;
    SequencerTrackInfo getTrackInfo (int i) const;

    void setTrackEnabled (int i, bool enabled);

    /** Returns the index of the SfPlayer track (a genuine SF2 preset track —
     *  isSfzInstrument == false) whose midiChannel (0-based) matches, or -1
     *  if none exists. Used to keep the SF2 internal mixer's per-channel
     *  strips in sync with the Arranger's track selection/mute — the two
     *  otherwise track independent state (SfzPlayer::ChannelStrip vs.
     *  SequencerTrack), so this lookup is how callers bridge channel ->
     *  track. */
    int findSfTrackForChannel (int midiChannel0Based) const;

    /** Solo follows standard mixer convention: while any track is soloed,
     *  only soloed tracks are audible, regardless of their own enabled/mute
     *  state. Clearing solo on all tracks restores normal enabled-based
     *  gating. */
    void setTrackSolo (int i, bool solo);

    /** Stored on the track and persisted; not yet applied to audio output. */
    void setTrackVolumeDb (int i, float volumeDb);
    /** Stored on the track and persisted; not yet applied to audio output. -1..+1 */
    void setTrackPan (int i, float pan);

    void addMainTrack();
    void addChromaticTrack (int sliceIdx, int chromaticChannel,
                            const juce::String& name, juce::Colour colour);
    void removeChromaticTrack (int sliceIdx);
    void addSfTrack (const Sf2PresetInfo& preset, juce::Colour colour);
    void removeSfTrack (int trackIndex);
    void rebuildSfTracks (const std::vector<Sf2PresetInfo>& presets,
                          const juce::Colour* palette, int paletteSize);

    /** Add or update an SF2 track for a given preset on a specific MIDI channel (0-based).
     *  If a track already exists for this preset, its channel is updated.
     *  Also calls sfzPlayer->setPresetOnChannel() so audio follows immediately. */
    void addOrUpdateSfTrackOnChannel (const Sf2PresetInfo& preset, int midiChannel0Based,
                                      juce::Colour colour);

    /** Add or update the singleton real-.sfz-instrument track (see
     *  SequencerTrack::makeSfzInstrument()). If it already exists it's
     *  updated in place (name/colour/channel); otherwise it's created.
     *  Used both when a .sfz is loaded from the browser/drop and whenever
     *  the MULTISAMPLER instrument (built via Add Zone or otherwise) goes
     *  from zero to non-zero zones — see removeSfzTrack(). */
    void addSfzTrack (const juce::String& name, int midiChannel0Based, juce::Colour colour);

    /** Remove the singleton real-.sfz-instrument track, if present. No-op
     *  if it doesn't exist. Call whenever the MULTISAMPLER instrument's
     *  zone list becomes empty — see addSfzTrack(). */
    void removeSfzTrack();

    //==========================================================================
    //  Clip management  (message thread)
    //==========================================================================

    /** Returns the number of clips on a track. */
    int getNumClips (int trackIndex) const;

    /** Snapshot of a clip's position+length. */
    SequencerClipInfo getClipInfo (int trackIndex, int clipIndex) const;

    /** Direct access to a MidiClip for editing (piano roll). Null if out of range. */
    MidiClip* getClip (int trackIndex, int clipIndex = 0);

    /** Legacy single-clip accessor — main track clip 0. */
    MidiClip& getClip();

    /** Create a new empty clip on the track. Returns the new clip index. */
    int addClip (int trackIndex, int64_t startTick,
                 int64_t lengthTicks = MidiClip::kPPQ * 4 * 4);

    /** Delete a clip by index. */
    void removeClip (int trackIndex, int clipIndex);

    /** Move a clip's start position. */
    void setClipStartTick (int trackIndex, int clipIndex, int64_t newStartTick);

    /** Resize a clip. */
    void setClipLengthTicks (int trackIndex, int clipIndex, int64_t newLength);

    /** Backward-compat per-track length helpers (operate on clip 0). */
    int64_t getTrackLengthTicks (int trackIndex) const noexcept;
    void    setTrackLengthTicks (int trackIndex, int64_t ticks);

    //==========================================================================
    //  Audio thread
    //==========================================================================
    void processBlock (juce::MidiBuffer& outMidi, const juce::MidiBuffer& inMidi,
                       int numSamples, double sampleRate);

    //==========================================================================
    //  Serialisation
    //==========================================================================
    void writeToStream (juce::MemoryOutputStream& s) const;
    bool readFromStream (juce::MemoryInputStream& s);

    //==========================================================================
    //  Ableton Link
    //==========================================================================
    void setAbletonLink (AbletonLink* l) noexcept;

    //==========================================================================
    //  SfzPlayer integration  (multi-timbral channel assignment)
    //==========================================================================
    /** Store a pointer to the SfzPlayer so that rebuildSfTracks() and
     *  addSfTrack() can call setPresetOnChannel() automatically.
     *  Call once from PluginProcessor constructor, before any SF2 is loaded. */
    void setSfzPlayer (class SfzPlayer* player) noexcept;

    /** Set which FluidSynth channel should receive live controller (ch-1) input.
     *  Pass the 0-based midiChannel of the selected SF track, or -1 for none.
     *  Called by ArrangeView whenever the selected track changes. */
    void setSelectedSfLiveChannels (uint16_t channelMask) noexcept;

    /** Returns a bitmask (bit N = channel N+1) covering every SfPlayer track's
     *  assigned MIDI channel.  Used by setMidiRouteMode() to direct all live
     *  input to the SF-player when SF-player mode is active. */
    uint16_t getAllSfPlayerChannelMask() const noexcept;

    //==========================================================================
    //  Live MIDI channel for the selected arranger track
    //==========================================================================

    /** Set the MIDI channel (1-based) that live input should be re-stamped to
     *  when the arranger is active.  Pass 0 to disable re-stamping (SfPlayer
     *  tracks handle their own routing via liveInputChannelMask).
     *  Called from ArrangeView::selectTrack on the message thread — atomic.
     *  @deprecated Prefer setSelectedTrack(), which also lets the engine
     *  resolve the target player type for getSelectedLiveTarget(). Kept for
     *  any call sites that only care about the re-stamp channel. */
    void setSelectedLiveChannel (int ch1Based) noexcept;

    /** Returns the current selected live channel (1-16), or 0 if none. */
    int  getSelectedLiveChannel() const noexcept;

    /** Set which arranger track index is currently selected in the UI.
     *  Pass -1 when nothing is selected. Derives and caches both the
     *  re-stamp channel (as returned by getSelectedLiveChannel()) and the
     *  target player (as returned by getSelectedLiveTarget()) from that
     *  track's type/isSfzInstrument/midiChannel.
     *  Called from ArrangeView::selectTrack on the message thread — atomic. */
    void setSelectedTrack (int trackIndex) noexcept;

    /** Returns the live-MIDI destination (player + channel) for the
     *  currently selected arranger track, per
     *  docs/selected-track-live-midi-workflow.md:
     *    - MainSlice / ChromaticSlice track selected -> LiveTargetPlayer::slicer
     *    - SfPlayer track selected, isSfzInstrument == false -> LiveTargetPlayer::sf2
     *    - SfPlayer track selected, isSfzInstrument == true  -> LiveTargetPlayer::sfz
     *    - nothing selected / out of range               -> LiveTargetPlayer::none
     *  Safe to call from the audio thread (lock-free snapshot read). */
    SelectedLiveTarget getSelectedLiveTarget() const noexcept;

    /** Returns a bitmask (bit N = channel N+1, 0-based) covering every
     *  SfPlayer track whose isSfzInstrument flag is set — i.e. real .sfz
     *  arranger tracks, as opposed to SF2-preset SfPlayer tracks. Used so
     *  processBlock() can make sure sfzPlayer2 listens on those channels. */
    uint16_t getSfzInstrumentChannelMask() const noexcept;

    /** Tell the engine which track index receives recorded MIDI.
     *  Call alongside setSelectedLiveChannel when the user selects a track.
     *  Pass -1 to disable recording. */
    void setRecordingTrack (int trackIndex) noexcept;

    /** Which track index currently receives recorded MIDI, -1 if none.
     *  Today this mirrors track selection (see ArrangeView's selection
     *  handler) rather than an independent per-track arm state — added so
     *  TrackHeaderStrip's R button can show the real target instead of a
     *  UI-only stand-in. */
    int getRecordingTrackIndex() const noexcept;

    /** Drains recorded-note events captured by the audio thread during
     *  processBlock() and applies them to the target clip via
     *  MidiClip::addNote()/setNoteDuration().
     *
     *  MESSAGE-THREAD ONLY. The audio thread never touches MidiClip during
     *  recording — it resolves a clip-relative tick and pushes a small POD
     *  event into a lock-free FIFO; this is the only place that still calls
     *  the (audio-thread-illegal) MidiClip editing calls for recording.
     *  Call this periodically (e.g. from a UI Timer) while recording. */
    void drainRecordedEvents();

    //==========================================================================
    //  Per-track MIDI activity flags (for the receive indicator in TrackHeaderStrip)
    //==========================================================================

    static constexpr int kActivityFlagCount = 64;

    /** Returns true and clears the flag if the audio thread set it since last
     *  call.  Safe to call from the message thread (atomic exchange). */
    bool getMidiActivityAndClear (int trackIndex) noexcept;

private:
    struct Impl;
    std::unique_ptr<Impl> impl;
};
